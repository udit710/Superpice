package au.edu.rmit.sept.superprice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SuperPriceApplication {

	public static void main(String[] args) {
		SpringApplication.run(SuperPriceApplication.class, args);
	}

}
