package au.edu.rmit.sept.superprice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SuperPriceApplicationTests {

	@Test
	void contextLoads() {
	}

}
